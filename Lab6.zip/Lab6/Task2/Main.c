#include <stdio.h>
#include <stdarg.h>

int fibonacci(char c, ...)
{
    va_list arg_list;
    va_start(arg_list, c);
    int num=va_arg(arg_list,int), res = -1;
    while (num!=-1)
    {
        res = num + 1;
        num = va_arg(arg_list, int);
    }
    return res;
}

int main()
{
    printf("%i", fibonacci('a', 1, 1, 2, 3, 5, -1));

    return 0;
}